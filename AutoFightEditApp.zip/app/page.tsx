import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function AutoFightEdit() {
  const [videoFile, setVideoFile] = useState(null);
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleUpload = () => {
    if (videoFile && email) {
      setSubmitted(true);
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto text-center">
      <h1 className="text-3xl font-bold mb-4">AutoFight Edit</h1>
      <p className="mb-4">Upload your sparring footage. We'll return a cinematic highlight with slow-mo, subtitles, and fighter overlay.</p>

      {!submitted ? (
        <Card className="p-4">
          <CardContent className="space-y-4">
            <Input
              type="file"
              accept="video/*"
              onChange={(e) => setVideoFile(e.target.files[0])}
            />
            <Input
              type="email"
              placeholder="Your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Button onClick={handleUpload} disabled={!videoFile || !email}>
              Upload & Process
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="mt-6">
          <p className="text-green-600 font-semibold text-xl">✅ Video received!</p>
          <p>We’ll send your cinematic fight reel to your email within 24 hours.</p>
        </div>
      )}
    </div>
  );
}